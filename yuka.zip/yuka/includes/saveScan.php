<?php

include './dbh.php';
$response = array();

$name = $_POST['name'];
$image = $_POST['image'];
$nutriScore = $_POST['nutriScore'];
$energy = $_POST['energy'];
$protein = $_POST['protein'];
$fiber = $_POST['fiber'];
$sugarLevelClass = $_POST['sugarLevelClass'];
$sugar = $_POST['sugar'];
$fat = $_POST['fat'];
$salt = $_POST['salt'];
$negatives = $_POST['negatives'];
$score = $_POST['score'];



$id = generate_uuid_v4();
$sql = "INSERT INTO `save`(`id`, `name`, `image`, `nutriScore`, `energy`, `protein`, `fiber`, `sugarLevelClass`,`sugar`,`fat`,`salt`,`negatives`,`score`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
$statement = $conn ->prepare($sql);
$statement->bind_param('sssssssssssss' ,$id,$name,$image,$nutriScore,$energy,$protein,$fiber,$sugarLevelClass,$sugar,$fat,$salt,$negatives,$score);
$statement->execute();





var_dump($name,$image,$nutriScore,$energy,$protein,$fiber,$sugarLevelClass);
echo json_encode($response);

?>